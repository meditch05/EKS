#!/bin/bash

if [ $# -ne 3 ]; then
  echo $#
  echo "Usage ] DOCKER_REGISTRY_URL IMAGE_NAME IMAGE_TAGS"
  echo "Sample] zcplocal.icp:8500 image_name image_tags"
  exit;
fi

DOCKER_REGISTRY=$1
IMAGE_NAME=$2
IMAGE_TAGS=$3

echo "====================="
echo "Docker Registry Login"
echo "====================="
# docker login zcplocal.icp:8500 -u admin -p admin
docker login ${DOCKER_REGISTRY} -u admin -p admin

# docker rmi $IMAGE_NAME:$IMAGE_TAGS zcplocal.icp:8500/infra/$IMAGE_NAME:$IMAGE_TAGS
# docker build --rm=true --tag $DOCKER_IMAGE .

echo "================================"
echo "Docker Image Check(Local Docker)"
echo "================================"
docker images | grep $IMAGE_NAME:$IMAGE_TAGS

echo "====================="
echo "Docker Image Tagging "
echo "====================="
# docker tag $IMAGE_NAME:$IMAGE_TAGS zcplocal.icp:8500/infra/$IMAGE_NAME:$IMAGE_TAGS
docker tag $IMAGE_NAME:$IMAGE_TAGS ${DOCKER_REGISTRY}/infra/$IMAGE_NAME:$IMAGE_TAGS

echo "====================="
echo "Docker Image Push"
echo "====================="
docker push ${DOCKER_REGISTRY}/infra/$IMAGE_NAME:$IMAGE_TAGS

echo "====================="
echo "Docker Image ListUp  "
echo "====================="
docker images | grep $IMAGE_NAME | grep $IMAGE_TAGS
