#!/bin/bash

if [ $# -lt 1 ]; then
  echo "dockertags  --  list all tags for a Docker image on a remote registry."
  echo ""
  echo "EXAMPLE:"
  echo "    - list all tags for ubuntu:"
  echo "       dockertags ubuntu"
  echo ""
  echo "    - list all php tags containing apache:"
  echo "       dockertags php apache"
fi

image="$1"
tags=`wget -q https://registry.hub.docker.com/v1/repositories/${image}/tags -O -  | sed -e 's/[][]//g' -e 's/"//g' -e 's/ //g' | tr '}' '\n'  | awk -F: '{print $3}'`

if [ -n "$2" ]; then
    tags=` echo "${tags}" | grep "$2" `
fi

echo "${tags}"
