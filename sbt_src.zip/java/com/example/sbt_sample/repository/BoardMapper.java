package com.example.sbt_sample.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.example.sbt_sample.entity.Board;

import java.util.List;

/*
- JPA 처리를 담당하는 Repository는 기본적으로 4가지가 있다. (T : Entity의 타입클래스, ID : P.K 값의 Type)
1) Repository<T, ID>
2) CrudRepository<T, ID>
3) PagingAndSortingRepository<T, ID>
4) JpaRepository<T, ID>
출처: https://goddaehee.tistory.com/209 [갓대희의 작은공간]
*/
	
@Repository
public interface BoardMapper extends JpaRepository<Board, Long>{
	
    // @Insert("INSERT INTO WSC.BOARDS (USER_ID, TITLE, CONTENT, CREATE_TIME) VALUES (#{userId}, #{title}, #{content}, #{create_time})")
    // @SelectKey(statement = "SELECT LAST_INSERT_ID()", keyProperty = "id", before = false, resultType = int.class)
	Board save(Board board);
	
	List<Board> findAll();

	Board findById(@Param("id") int id);
	Board deleteById(@Param("id") int id);
	
	Board findByUserId(@Param("userId") int userId);
	
	
	/*
    @Update("UPDATE WSC.BOARDS SET TITLE = #{title}, CONTENT = #{content} WHERE ID = #{id}")
    void update(Board board);
    
    @Select("SELECT * FROM WSC.BOARDS")
    List<Board> findAll();
    
    @Select("SELECT * FROM WSC.BOARDS WHERE ID = #{id}")
    Board findOne(@Param("id") int id);

    @Delete("DELETE FROM WSC.BOARDS WHERE ID = #{id}")
    void delete(@Param("id") int id);

    @Select("SELECT * FROM WSC.BOARDS WHERE USER_ID = #{userId}")
    Board findOneByUserId(@Param("userId") int userId);
    */
}
