package com.example.sbt_sample.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.example.sbt_sample.entity.User;

import java.util.List;

/*
- JPA 처리를 담당하는 Repository는 기본적으로 4가지가 있다. (T : Entity의 타입클래스, ID : P.K 값의 Type)
1) Repository<T, ID>
2) CrudRepository<T, ID>
3) PagingAndSortingRepository<T, ID>
4) JpaRepository<T, ID>
출처: https://goddaehee.tistory.com/209 [갓대희의 작은공간]
*/
	
@Repository
public interface UserMapper extends JpaRepository<User, Long>{
	
	List<User> findAll();
	
	User findById(@Param("id") int id);
	
	// @Insert("INSERT INTO USERS (NAME, INTRODUCE) VALUES (#{name}, #{introduce})")
	User save(User user);
	
	/*	
    @Insert("INSERT INTO USERS (NAME, INTRODUCE) VALUES (#{name}, #{introduce})")
    @SelectKey(statement = "SELECT LAST_INSERT_ID()", keyProperty = "id", before = false, resultType = int.class)
    void insert(User user);

    @Update("UPDATE USERS SET NAME = #{name}, INTRODUCE = #{introduce}, WHERE ID = #{id}")
    void update(User user);

    @Select("SELECT * FROM USERS WHERE ID = #{id}")
    User findOne(@Param("id") int id);
    
    @Select("SELECT * FROM USERS")
    List<User> findAll();

    @Delete("DELETE FROM USERS WHERE ID = #{id}")
    void delete(@Param("id") int id);
	*/
}
