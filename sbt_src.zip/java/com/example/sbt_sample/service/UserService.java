package com.example.sbt_sample.service;

import com.example.sbt_sample.entity.User;
import com.example.sbt_sample.repository.UserMapper;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Date;


@Service
public class UserService {
    @Autowired
    private UserMapper userMapper;

    public Boolean signup(User user) {
        if(user.getName() == null || user.getEmail() ==  null)
            return false;

        // userMapper.insert(user);
        userMapper.save(user);

        System.out.println("user created :" + new Date());
        return true;
    }
    
    public Boolean signedit(User user) {
        if(user.getEmail() == null || user.getPassword() ==  null)
            return false;

        user.setId(user.getId());
        user.setName(user.getName());
        user.setEmail(user.getEmail());
        user.setPassword(user.getPassword());
        userMapper.save(user);

        System.out.println("user edited :" + new Date());
        return true;
    }

}
