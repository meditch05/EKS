package com.example.sbt_sample.entity;

// import org.springframework.security.core.context.SecurityContextHolder;

import javax.persistence.*;
// import javax.persistence.Entity;
// import javax.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/*
	CREATE TABLE `USERS` (
		`ID` 		int(10) unsigned NOT NULL AUTO_INCREMENT,
		`NAME` 		varchar(45)		DEFAULT NULL,
		`EMAIL` 	varchar(255)	DEFAULT NULL,
		`PASSWORD`	varchar(255)	DEFAULT NULL,
		PRIMARY KEY (`ID`)
	);
 */

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "users")
public class User {
	
	@Id                 		// 에러방지를 위한 어노테이션 2개 ( Invocation of init method failed; nested exception is org.hibernate.AnnotationException: No identifier specified for entity: com.example.sbt_sample.domain.User )
	@Column(name="ID")  		// Entity 선언시 식별자를 선언해주지 않아서 발생하는 에러임, PK 속성의 컬럼명에 지정함
    private int 	id; 		// DB에 저장할 primary key
    private String	name; 		// 회원의 이름
    private String	email;  	// 회원 소갯말
    private String	password;  	// 회원 소갯말

    public int getId()							{	return id;			}
    public void setId(int id)					{	this.id = id;		}

    public String getName()						{	return name;		}
    public void setName(String name)			{	this.name = name;	}

    public String getEmail() 					{	return email;		}
    public void setEmail(String email) 			{	this.email = email;	}
    
    public String getPassword() 				{	return password;			}
    public void setPassword(String password) 	{	this.password = password;	}
    
    
    public boolean isAccountNonExpired()		{	return true;		}
    public boolean isAccountNonLocked()			{	return true;		}
    public boolean isCredentialsNonExpired()	{	return true;		}
    public boolean isEnabled()					{	return true;		}

    /*
    public static User current() {
        try {
            return (User) SecurityContextHolder.getContext()
                    .getAuthentication().getPrincipal();
        } catch (Exception e) {
            return null;
        }
    }
    */
    
    @Override
    public String toString() {
        return "User{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", email='" + email + '\'' +
                ", password='" + password + '\'' +
                '}';
    }
}
