package com.example.sbt_sample.entity;

import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/*
	CREATE TABLE `BOARDS` (
		`ID` 			int(11) NOT NULL AUTO_INCREMENT,
		`USER_ID` 		int(10) unsigned NOT NULL,
		`TITLE` 		varchar(45) NOT NULL,
		`CONTENT` 		varchar(255) NOT NULL,
		`CREATE_TIME`	datetime DEFAULT NULL,
		PRIMARY KEY (`ID`)
	);
 */

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "boards")
public class Board {
	
	@Id                 		// 에러방지를 위한 어노테이션 2개 ( Invocation of init method failed; nested exception is org.hibernate.AnnotationException: No identifier specified for entity: com.example.sbt_sample.domain.User )
	@Column(name="ID")  		// Entity 선언시 식별자를 선언해주지 않아서 발생하는 에러임, PK 속성의 컬럼명에 지정함
    private int id;
    private int userId;
    private String title;
    private String content;
    private Date createTime;    

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getUserId() {
        return userId;
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getContent() {
        return content;
    }
    
    public void setContent(String content) {
        this.content = content;
    }

    public Date getCreatetime() {
        return createTime;
    }

    public void setCreatetime(Date createTime) {
        this.createTime = createTime;
    }

    @Override
    public String toString() {
        return "BoardInfo{" +
                "id=" + id +
                ", userId=" + userId +
                ", title='" + title + '\'' +
                ", content='" + content + '\'' +
                ", createTime='" + createTime + '\'' +
                '}';
    }
}