package com.example.sbt_sample.controller.restapi;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.util.UriComponentsBuilder;

import com.example.sbt_sample.entity.Board;
import com.example.sbt_sample.repository.BoardMapper;

import java.util.List;

@RestController
@RequestMapping("/api")
public class BoardRestController {
    @Autowired
    private BoardMapper boardMapper;

    // Read
    // 작성한 글의 id로 정보를 받음
    @Transactional
    @RequestMapping(value="/board/{id}", method= RequestMethod.GET, produces = "application/json")
    public ResponseEntity<Board> board(@PathVariable("id") int id) {
        Board board = boardMapper.findById(id);
        if (board == null) {
            System.out.println("데이터가 존재하지 않습니다.");
            return new ResponseEntity<Board>(HttpStatus.NOT_FOUND);
        }
        return new ResponseEntity<Board>(board, HttpStatus.OK);
    }


    // Create
    // 클라이언트에서 작성한 정보를 서버로
    @Transactional
    @RequestMapping(value = "/board/", method = RequestMethod.POST)
    public ResponseEntity<Void> createBoard(@RequestBody Board board, UriComponentsBuilder ucBuilder) {
        if (boardMapper.findByUserId(board.getUserId()) != null) {
            System.out.println("이미 이 유저는 글을 작성했습니다.");
            return new ResponseEntity<Void>(HttpStatus.CONFLICT);  // 409
        }

        boardMapper.save(board);
        HttpHeaders headers = new HttpHeaders();
        headers.setLocation(
                ucBuilder.path("/board/{id}").buildAndExpand(board.getId()).toUri()
                );
        return new ResponseEntity<Void>(headers, HttpStatus.CREATED);  // 201
    }


    // Update
    // 수정 정보를 처리
    @Transactional
    @RequestMapping(value = "/board/{id}", method = RequestMethod.PUT)
    public ResponseEntity<Void> updateBoard(@PathVariable("id") int id, @RequestBody Board board) {
    	Board storedBoard = boardMapper.findById(id);

        if (storedBoard == null) {
            System.out.println("해당 글이 존재하지 않습니다.");
            return new ResponseEntity<Void>(HttpStatus.NOT_FOUND);
        }

        storedBoard.setTitle(board.getTitle());
        storedBoard.setContent(board.getContent());

        boardMapper.save(storedBoard);

        return new ResponseEntity<Void>(HttpStatus.OK);
    }


    // DELETE
    // 정보 삭제하기
    @Transactional
    @RequestMapping(value = "/board/{id}", method = RequestMethod.DELETE)
    public ResponseEntity<Board> deleteBoard(@PathVariable("id") int id) {
        Board storedBoard = boardMapper.findById(id);

        if (storedBoard == null) {
            System.out.println("삭제하려는 대상을 찾을 수 없습니다.");
            return new ResponseEntity<Board>(HttpStatus.NOT_FOUND);
        }

        boardMapper.deleteById(storedBoard.getId());

        return new ResponseEntity<Board>(HttpStatus.NO_CONTENT);
    }
}
