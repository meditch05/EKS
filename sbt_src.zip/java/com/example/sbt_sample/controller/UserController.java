package com.example.sbt_sample.controller;

import com.example.sbt_sample.entity.User;
import com.example.sbt_sample.repository.UserMapper;
import com.example.sbt_sample.service.UserService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/user")
public class UserController {
	
	@Autowired
    private UserMapper userMapper;
	@Autowired
    private UserService userService;
    // @inject 어노테이션을 통해 UserService를 불러옵니다.
	// @Inject     는 Java에서    제공하는 Annotation
	// @@Autowired 는 Spring에서 제공하는 Annotation   

    
    // 회원정보 버튼을 눌렀을 때
    @RequestMapping("/info")
    public String userinfo(Model model) {
        model.addAttribute("users", userMapper.findAll());
        return "user/info";
    }
    
    // 회원 추가 버튼을 눌렀을 때
    @RequestMapping("/signup")
    public String signup(Model model) {
        User user = new User();
        model.addAttribute("user", user);
     
        return "user/signup";
    }
    
    // 회원 추가 데이터를 받았을 때
    @Transactional
    @RequestMapping(value="/signup", method= RequestMethod.POST)
    public String signup(@ModelAttribute User user) {
        userService.signup(user);
        return "redirect:/user/info";
    }
    
    // 회원 정보 수정 페이지
    @RequestMapping(value = "/edit", method = RequestMethod.GET)
    public String edit(@RequestParam int id, Model model) {
    	
    	System.out.println("List에서 '정보수정' 누름");
    	
        model.addAttribute("user", userMapper.findById(id));        
        return "user/edit";
    }

    // 회원 정보 수정에 대한 데이터를 받았을 때
    @RequestMapping(value = "/edit", method = RequestMethod.POST)
    public String edit(@ModelAttribute User user) {
    	
    	System.out.println("수정화면에서 수정하기 누름");
        System.out.println("user = " + user);
        
        userService.signedit(user);
        // userMapper.update(user);
        
        return "redirect:/user/info";
        // return "user/info";
    }

}

