package com.example.sbt_sample.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/character/*")
public class CharacterController {
    @RequestMapping("/elice_rabbit")
    public String elice_rabbit() {
        return "character/elice_rabbit";
    }
    
    @RequestMapping("/cheshire_cat")
    public String cheshire_cat() {
        return "character/cheshire_cat";
    }
    
    @RequestMapping("/caterpillar")
    public String caterpillar() {
        return "character/caterpillar";
    }
    
    @RequestMapping("/queen_of_hearts")
    public String queen_of_hearts() {
        return "character/queen_of_hearts";
    }
}
