#!/bin/bash

helm fetch stable/prometheus --version 11.5.0
