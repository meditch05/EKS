#!/bin/bash

helm fetch stable/grafana --version 5.0.26
