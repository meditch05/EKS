#!/bin/bash

helm repo add bitnami https://charts.bitnami.com
