#!/bin/bash

curl https://cloud.weave.works/k8s/net?k8s-version=1.15.0 > weavenet.k8s.1.15.0
