helm inspect values stable/jenkins > values.jenkins.yaml.ori
