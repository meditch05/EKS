#!/bin/bash

sudo yum install mariadb
sudo yum install python
python --version
curl -O https://bootstrap.pypa.io/get-pip.py
python get-pip.py --user



pip install pymysql -t .
cd ..
zip -r9 ../pymysql.zip .
aws lambda publish-layer-version --layer-name 05580-pymysql \
--zip-file fileb://../pymysql.zip \
--compatible-runtimes python2.7
